var structsttcl_1_1internal_1_1_ref_count_ptr_base_1_1_ptr_ref =
[
    [ "PtrRef", "structsttcl_1_1internal_1_1_ref_count_ptr_base_1_1_ptr_ref.html#a9b782b789a31396a4a361848e3cc7f3c", null ],
    [ "~PtrRef", "structsttcl_1_1internal_1_1_ref_count_ptr_base_1_1_ptr_ref.html#ae54a03d90017d178d69e1a53c5e4c29e", null ],
    [ "pointee", "structsttcl_1_1internal_1_1_ref_count_ptr_base_1_1_ptr_ref.html#a02afc0855ebe4e12d013472adba2d4f8", null ],
    [ "refcount", "structsttcl_1_1internal_1_1_ref_count_ptr_base_1_1_ptr_ref.html#aabfaacbd4372f7e580a78f5b130f1bd3", null ],
    [ "refcountMutex", "structsttcl_1_1internal_1_1_ref_count_ptr_base_1_1_ptr_ref.html#a7481aafffbf482d84ee4206b1f0a8b2f", null ],
    [ "releaseFunc", "structsttcl_1_1internal_1_1_ref_count_ptr_base_1_1_ptr_ref.html#a37bc79bb3afb2d8c8ee98a2d705dbd91", null ]
];