var structsttcl_1_1internal_1_1_event_args_interface_selector =
[
    [ "InnerEventHandler", "structsttcl_1_1internal_1_1_event_args_interface_selector.html#a47949185f981b6d23314d046921354c4", null ],
    [ "RefCountPtr", "structsttcl_1_1internal_1_1_event_args_interface_selector.html#acb69c6b3fa33c956e2237ffec87604a5", null ]
];