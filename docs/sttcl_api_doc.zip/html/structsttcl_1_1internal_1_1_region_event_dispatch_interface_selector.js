var structsttcl_1_1internal_1_1_region_event_dispatch_interface_selector =
[
    [ "RESULT_TYPE", "structsttcl_1_1internal_1_1_region_event_dispatch_interface_selector.html#a23c278b033d62b12b206893f8b53469e", null ]
];