var structsttcl_1_1internal_1_1_region_base_implementation_selector =
[
    [ "RESULT_TYPE", "structsttcl_1_1internal_1_1_region_base_implementation_selector.html#a7dfb628901b4c735073030831df2ed80", null ]
];