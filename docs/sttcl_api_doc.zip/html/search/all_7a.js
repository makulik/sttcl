var searchData=
[
  ['zero',['Zero',['../classsttcl_1_1_time_duration.html#a3f7bb56a56c77172e157e5de04aaa64b',1,'sttcl::TimeDuration']]]
];
