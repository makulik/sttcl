var searchData=
[
  ['timeduration',['TimeDuration',['../classsttcl_1_1_time_duration.html#a8f2fa1d0e5e096c98138c3e0c43a87ca',1,'sttcl::TimeDuration::TimeDuration(unsigned int argHours=0, unsigned int argMinutes=0, unsigned int argSeconds=0, unsigned int argMilliSeconds=0, unsigned long argMicroSeconds=0, unsigned long argNanoSeconds=0)'],['../classsttcl_1_1_time_duration.html#a45481a7d56de9a85bbc512c906bd3b83',1,'sttcl::TimeDuration::TimeDuration(const TimeDuration&lt; Implementation &gt; &amp;rhs)'],['../classsttcl_1_1_time_duration.html#a1d466cf0fbd2b729aab0b3e0a46ea9f9',1,'sttcl::TimeDuration::TimeDuration(const NativeTimeDuration &amp;nativeTimeDuration)']]],
  ['try_5flock',['try_lock',['../classsttcl_1_1internal_1_1_sttcl_mutex.html#a480bd752497d389285b6095a73150f37',1,'sttcl::internal::SttclMutex']]],
  ['try_5fwait',['try_wait',['../classsttcl_1_1internal_1_1_sttcl_semaphore.html#a77c69482fd277f429f008828e4ec38d3',1,'sttcl::internal::SttclSemaphore']]]
];
