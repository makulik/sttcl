var searchData=
[
  ['context',['context',['../structsttcl_1_1internal_1_1_dispatched_event.html#a09c94b1f1645d30c9e5034db164a880d',1,'sttcl::internal::DispatchedEvent']]]
];
