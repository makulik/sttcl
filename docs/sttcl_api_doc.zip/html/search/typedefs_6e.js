var searchData=
[
  ['nativetimeduration',['NativeTimeDuration',['../classsttcl_1_1_time_duration.html#af440573cd9be703b0df0b3078840afe3',1,'sttcl::TimeDuration']]]
];
