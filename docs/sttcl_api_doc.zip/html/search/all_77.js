var searchData=
[
  ['wait',['wait',['../classsttcl_1_1internal_1_1_sttcl_semaphore.html#a29bf4dce585b1e961e2a7cc6cb36f2c9',1,'sttcl::internal::SttclSemaphore']]],
  ['waitforevents',['waitForEvents',['../classsttcl_1_1_event_queue.html#a63d4f8a8e747eb3abf8cd21778531c17',1,'sttcl::EventQueue::waitForEvents()'],['../classsttcl_1_1_event_queue.html#aa2719d4bafdf9ad58ed51bcfcca97618',1,'sttcl::EventQueue::waitForEvents(TimeDurationType timeout)']]]
];
