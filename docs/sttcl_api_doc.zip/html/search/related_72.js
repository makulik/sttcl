var searchData=
[
  ['regionbase_3c_20regioncontainerimpl_2c_20iinnerstate_2c_20eventargs_20_3e',['RegionBase&lt; RegionContainerImpl, IInnerState, EventArgs &gt;',['../classsttcl_1_1_region.html#a201b1cf2085e9f42add46984fb40582c',1,'sttcl::Region']]]
];
