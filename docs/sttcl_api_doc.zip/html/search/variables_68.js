var searchData=
[
  ['handler',['handler',['../structsttcl_1_1internal_1_1_dispatched_event.html#a832e343e93d7289b61955efe86a2a1d4',1,'sttcl::internal::DispatchedEvent']]]
];
