var searchData=
[
  ['pointee',['pointee',['../structsttcl_1_1internal_1_1_ref_count_ptr_base_1_1_ptr_ref.html#a02afc0855ebe4e12d013472adba2d4f8',1,'sttcl::internal::RefCountPtrBase::PtrRef']]],
  ['ptrref',['ptrRef',['../classsttcl_1_1internal_1_1_ref_count_ptr_base.html#ac3ebf4f05dc617734ff3809f1fa40064',1,'sttcl::internal::RefCountPtrBase']]]
];
