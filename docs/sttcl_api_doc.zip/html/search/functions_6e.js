var searchData=
[
  ['nanoseconds',['nanoseconds',['../classsttcl_1_1_time_duration.html#a7ab4fa0e634996abfb22133b5093ca13',1,'sttcl::TimeDuration']]]
];
