var searchData=
[
  ['state',['state',['../structsttcl_1_1internal_1_1_dispatched_event.html#a0b1dc10a6855d53388c09ac55c8b88e3',1,'sttcl::internal::DispatchedEvent']]]
];
