var searchData=
[
  ['microseconds',['microseconds',['../classsttcl_1_1_time_duration.html#a33439ba3896e20231600db28538ed421',1,'sttcl::TimeDuration']]],
  ['milliseconds',['milliseconds',['../classsttcl_1_1_time_duration.html#aca63fdee9a051c72643b0f516cfd8b66',1,'sttcl::TimeDuration']]],
  ['minutes',['minutes',['../classsttcl_1_1_time_duration.html#a5f14a2662a27957f1884c553f6e07b3e',1,'sttcl::TimeDuration::minutes() const '],['../classsttcl_1_1_time_duration.html#a30ad134c46f50c927e8146cbd29182e4',1,'sttcl::TimeDuration::minutes(int newMinutes)']]]
];
