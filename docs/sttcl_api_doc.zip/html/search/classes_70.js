var searchData=
[
  ['ptrref',['PtrRef',['../structsttcl_1_1internal_1_1_ref_count_ptr_base_1_1_ptr_ref.html',1,'sttcl::internal::RefCountPtrBase']]]
];
